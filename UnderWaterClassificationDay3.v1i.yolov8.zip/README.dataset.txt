# UnderWaterClassificationDay3 > 2026-01-07 11:28am
https://universe.roboflow.com/nitttr-djalz/underwaterclassificationday3-4l6n2

Provided by a Roboflow user
License: CC BY 4.0

