# FISH_CORAL > 2026-01-02 12:25pm
https://universe.roboflow.com/coral-cny2u/fish_coral

Provided by a Roboflow user
License: CC BY 4.0

